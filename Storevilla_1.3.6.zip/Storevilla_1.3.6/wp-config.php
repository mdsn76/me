<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '3nb<-D4LSeM_),N|HERv5i1(vB`>]]}WG&5g%I6*,AB#b,Y4L}alT?RTi:QR#5e}' );

define( 'SECURE_AUTH_KEY',  '/0,i,N,Q!b|?Dd@1r>{Pg`X$GQ$7n; Q Os]m}ZgoOI&,!-Gz>k=fr]oCF@K$iF?' );

define( 'LOGGED_IN_KEY',    'E9f#Q|Yk+GU3qo[QLaj`YVTZ(E|2/W$<&-2zB,u6v~a[6~E0N</olkLV&A}3>x`q' );

define( 'NONCE_KEY',        'c&i!:};v!TYiW|5XDXb*md;5Mi)h=5:ZI {vysEL2y2|y1bhwgjhE*Rhu&E/Vs^a' );

define( 'AUTH_SALT',        'at-|k=s{O2-@F(vl{20A3SZ|_p=0+pr7&LsxYs!*V1<^`rh{[~crvK.X*U??y7FT' );

define( 'SECURE_AUTH_SALT', 'rB9~p@BDv8d<f?N?7&3OAP H@m#`$X3Xuq5aG PH-)JKS!-k|paPq`MktN;)apBX' );

define( 'LOGGED_IN_SALT',   'wH_n!ZhR777W=5%IT&BawM3rME]5v;`_NlwW{b{vUn>+e_mjb H#pJzr75B+GfXn' );

define( 'NONCE_SALT',       'G67Q!d>I:3/L7)O.</$T;)rts6~o9xm0sD^s;Np;awKW-3@kQ7bDT%IC]VtVqS=|' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

